"use strict";

/**
 * add event on element
 */

const addEventOnElem = function (elem, type, callback) {
    if (elem.length > 1) {
        for (let i = 0; i < elem.length; i++) {
            elem[i].addEventListener(type, callback);
        }
    } else {
        elem.addEventListener(type, callback);
    }
};

/**
 * navbar toggle
 */

const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const navbar = document.querySelector("[data-navbar]");
const navbarLinks = document.querySelectorAll("[data-nav-link]");
const overlay = document.querySelector("[data-overlay]");

const toggleNavbar = function () {
    navbar.classList.toggle("active");
    overlay.classList.toggle("active");
};

addEventOnElem(navTogglers, "click", toggleNavbar);

const closeNavbar = function () {
    navbar.classList.remove("active");
    overlay.classList.remove("active");
};

addEventOnElem(navbarLinks, "click", closeNavbar);

/**
 * header sticky & back top btn active
 */

const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

const headerActive = function () {
    if (window.scrollY > 150) {
        header.classList.add("active");
        backTopBtn.classList.add("active");
    } else {
        header.classList.remove("active");
        backTopBtn.classList.remove("active");
    }
};

addEventOnElem(window, "scroll", headerActive);

let lastScrolledPos = 0;

const headerSticky = function () {
    if (lastScrolledPos >= window.scrollY) {
        header.classList.remove("header-hide");
    } else {
        header.classList.add("header-hide");
    }

    lastScrolledPos = window.scrollY;
};

addEventOnElem(window, "scroll", headerSticky);

/**
 * scroll reveal effect
 */

const sections = document.querySelectorAll("[data-section]");

const scrollReveal = function () {
    for (let i = 0; i < sections.length; i++) {
        if (sections[i].getBoundingClientRect().top < window.innerHeight / 2) {
            sections[i].classList.add("active");
        }
    }
};

scrollReveal();

addEventOnElem(window, "scroll", scrollReveal);

// =====================

var total = 0;

function load() {
    fetchCollectionAndDisplay();
    fetchProductAndDisplay();
    getFav();
    getCart();
}

function openFav() {
    window.location.href = "favorite.html";
}

function openCart() {
    window.location.href = "cart.html";
}

function clearFav() {
    fetch("/api/favorites", { method: "DELETE" })
    .then((response) => {
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        return response.json();
    })
    .then((data) => {
        console.log(data);
        alert(data.message);
        setTimeout(() => {
            window.location.reload();
        }, 500);
    })
    .catch((error) => {
        console.error("There was a problem fetching the data:", error);
    });
}


function clearCart() {
    fetch("/api/cart", { method: "DELETE" })
    .then((response) => {
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        return response.json();
    })
    .then((data) => {
        console.log(data);
        alert(data.message);
        setTimeout(() => {
            window.location.reload();
        }, 500);
    })
    .catch((error) => {
        console.error("There was a problem fetching the data:", error);
    });
}

function getCart() {
    fetch("/api/cart", { method: "GET"})
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then((data) => {
            total = 0;
            console.log(data);
            document.getElementById("cart-badge").innerHTML = data.length;
            const dataContainer = document.getElementById("cart");
            const carttotal = document.getElementById("cart-total");
            dataContainer.innerHTML = "";
            carttotal.innerHTML = "0";
            const table = document.createElement("table");
            table.classList.add("data-table");
            data.forEach((item) => {
                const tr = document.createElement("tr");
                tr.classList.add("table-row");

                const tdImage = document.createElement("td");
                const imgElement = document.createElement("img");
                imgElement.src = `http://localhost:5500/images/${item.image}`;
                imgElement.setAttribute("loading", "lazy");
                imgElement.setAttribute("width", "100");
                imgElement.setAttribute("alt", "Facial cleanser");
                tdImage.appendChild(imgElement);

                const tdName = document.createElement("td");
                const anchorElement = document.createElement("a");
                anchorElement.setAttribute("href", "#");
                anchorElement.classList.add("card-title");
                anchorElement.textContent = `${item.pname}`;
                tdName.appendChild(anchorElement);

                const tdPrice = document.createElement("td");
                const spanPrice = document.createElement("span");
                spanPrice.classList.add("span");
                spanPrice.textContent = `$${item.actualprice}`;
                tdPrice.appendChild(spanPrice);
                total += item.actualprice;

                const tdActions = document.createElement("td");
                // Add any action buttons or content here in tdActions

                tr.appendChild(tdImage);
                tr.appendChild(tdName);
                tr.appendChild(tdPrice);
                tr.appendChild(tdActions);

                table.appendChild(tr);
            });
            carttotal.innerHTML = `$${total}`;
            const trTotal = document.createElement("tr");
            trTotal.classList.add("table-row");

            const tdTotalLabel = document.createElement("td");
            tdTotalLabel.textContent = "Total:";
            tdTotalLabel.setAttribute("colspan", "2"); // Span two columns

            const tdTotalValue = document.createElement("td");
            tdTotalValue.textContent = `$${total}`;
            trTotal.appendChild(tdTotalLabel);
            trTotal.appendChild(tdTotalValue);
            table.appendChild(trTotal);
            dataContainer.appendChild(table);
        })
        .catch((error) => {
            console.error("There was a problem fetching the data:", error);
        });
}

function getFav() {
    fetch("/api/favorites")
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then((data) => {
            console.log(data);
            document.getElementById("fav-badge").innerHTML = data.length;
            const dataContainer = document.getElementById("favorites");
            dataContainer.innerHTML = "";

            data.forEach((item) => {
                // Create li element with class "scrollbar-item"
                const liElement = document.createElement("li");
                liElement.classList.add("scrollbar-item");

                // Create div element with class "shop-card"
                const divShopCard = document.createElement("div");
                divShopCard.classList.add("shop-card");

                // Create div element with class "card-banner" and style attributes
                const divCardBanner = document.createElement("div");
                // divCardBanner.classList.add("card-banner", "img-holder");
                // divCardBanner.style.setProperty("--width", "100");
                // divCardBanner.style.setProperty("--height", "auto");

                // Create img element with src, width, height, loading, and alt attributes
                const imgElement = document.createElement("img");
                imgElement.src = `http://localhost:5500/images/${item.image}`;
                imgElement.setAttribute("loading", "lazy");
                imgElement.setAttribute("width", "100");
                imgElement.setAttribute("alt", "Facial cleanser");
                // imgElement.classList.add("img-cover");

                // Create div element with class "card-actions"

                // Append elements to the card-banner div
                divCardBanner.appendChild(imgElement);

                // Create div element with class "card-content"
                const divCardContent = document.createElement("div");
                divCardContent.classList.add("card-content");

                // Create del element with class "del" and span element with class "span"
                const delElement = document.createElement("del");
                delElement.classList.add("del");
                delElement.textContent = `$${item.originalprice}`;

                const spanPrice = document.createElement("span");
                spanPrice.classList.add("span");
                spanPrice.textContent = `$${item.actualprice}`;

                // Append elements to the price div
                const divPrice = document.createElement("div");
                divPrice.classList.add("price");
                divPrice.appendChild(delElement);
                divPrice.appendChild(spanPrice);

                // Create h3 element with a nested anchor element
                const h3Element = document.createElement("h3");
                const anchorElement = document.createElement("a");
                anchorElement.setAttribute("href", "#");
                anchorElement.classList.add("card-title");
                anchorElement.textContent = `${item.pname}`;
                h3Element.appendChild(anchorElement);

                // Create div element with class "card-rating"
                const divCardRating = document.createElement("div");
                divCardRating.classList.add("card-rating");

                // Create div element with class "rating-wrapper" and nested ion-icon elements
                const divRatingWrapper = document.createElement("div");
                divRatingWrapper.classList.add("rating-wrapper");
                divRatingWrapper.setAttribute("aria-label", "5 start rating");

                for (let i = 0; i < item.stars; i++) {
                    const icon = document.createElement("ion-icon");
                    icon.setAttribute("name", "star");
                    icon.setAttribute("aria-hidden", "true");
                    divRatingWrapper.appendChild(icon);
                }

                // Create p element with class "rating-text"
                const pRatingText = document.createElement("p");
                pRatingText.classList.add("rating-text");
                pRatingText.textContent = `${item.reviews} reviews`;

                // Append elements to the card-rating div
                divCardRating.appendChild(divRatingWrapper);
                divCardRating.appendChild(pRatingText);

                // Append elements to the card-content div
                divCardContent.appendChild(divPrice);
                divCardContent.appendChild(h3Element);
                divCardContent.appendChild(divCardRating);

                // Append elements to the shop-card div
                divShopCard.appendChild(divCardBanner);
                divShopCard.appendChild(divCardContent);

                // Append the shop-card div to the li element
                liElement.appendChild(divShopCard);

                // Append the created li element to a parent element in your actual HTML document
                // For example, assuming you have an unordered list with ID 'scrollbarList'
                // const parentElement = document.getElementById("scrollbarList");
                dataContainer.appendChild(liElement);
            });
        })
        .catch((error) => {
            console.error("There was a problem fetching the data:", error);
        });
}

function fetchCollectionAndDisplay() {
    fetch("/api/collections")
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then((data) => {
            console.log(data);
            const dataContainer = document.getElementById("collection");
            dataContainer.innerHTML = "";
            const divCont = document.createElement("div");
            divCont.classList.add("container");

            const ulElement = document.createElement("ul");
            ulElement.classList.add("collection-list");
            data.forEach((item) => {
                const liElement = document.createElement("li");
                const divElement = document.createElement("div");
                divElement.classList.add("collection-card", "has-before", "hover:shine");

                const h2Element = document.createElement("h2");
                h2Element.classList.add("h2", "card-title");
                h2Element.textContent = item.title;

                const pElement = document.createElement("p");
                pElement.classList.add("card-text");
                pElement.textContent = "Starting at " + item.baseprice;

                const aElement = document.createElement("a");
                aElement.classList.add("btn-link");
                aElement.href = "#";

                const spanElement = document.createElement("span");
                spanElement.classList.add("span");
                spanElement.textContent = "Shop Now";

                const ionIconElement = document.createElement("ion-icon");
                ionIconElement.setAttribute("name", "arrow-forward");
                ionIconElement.setAttribute("aria-hidden", "true");

                aElement.appendChild(spanElement);
                aElement.appendChild(ionIconElement);

                const bgImageDivElement = document.createElement("div");
                bgImageDivElement.classList.add("has-bg-image");
                bgImageDivElement.style.backgroundImage = `url(http://localhost:5500/images/${item.image})`;

                divElement.appendChild(h2Element);
                divElement.appendChild(pElement);
                divElement.appendChild(aElement);
                divElement.appendChild(bgImageDivElement);

                liElement.appendChild(divElement);
                ulElement.appendChild(liElement);
            });
            divCont.appendChild(ulElement);
            dataContainer.appendChild(divCont);
        })
        .catch((error) => {
            console.error("There was a problem fetching the data:", error);
        });
}

function fetchProductAndDisplay() {
    fetch("/api/products")
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then((data) => {
            console.log(data);
            const dataContainer = document.getElementById("products");
            dataContainer.innerHTML = "";

            data.forEach((item) => {
                // Create li element with class "scrollbar-item"
                const liElement = document.createElement("li");
                liElement.classList.add("scrollbar-item");

                // Create div element with class "shop-card"
                const divShopCard = document.createElement("div");
                divShopCard.classList.add("shop-card");

                // Create div element with class "card-banner" and style attributes
                const divCardBanner = document.createElement("div");
                divCardBanner.classList.add("card-banner", "img-holder");
                divCardBanner.style.setProperty("--width", "540");
                divCardBanner.style.setProperty("--height", "720");

                // Create img element with src, width, height, loading, and alt attributes
                const imgElement = document.createElement("img");
                imgElement.src = `http://localhost:5500/images/${item.image}`;
                imgElement.setAttribute("width", "540");
                imgElement.setAttribute("height", "720");
                imgElement.setAttribute("loading", "lazy");
                imgElement.setAttribute("alt", "Facial cleanser");
                imgElement.classList.add("img-cover");

                // Create span element with class "badge" and aria-label attribute
                const spanBadge = document.createElement("span");
                spanBadge.classList.add("badge");
                spanBadge.setAttribute("aria-label", "20% off");
                spanBadge.textContent = `-${item.discount}%`;

                // Create div element with class "card-actions"
                const divCardActions = document.createElement("div");
                divCardActions.classList.add("card-actions");

                // Create three buttons with class "action-btn" and different aria-labels
                for (let i = 0; i < 2; i++) {
                    const button = document.createElement("button");
                    button.classList.add("action-btn");

                    const icon = document.createElement("ion-icon");
                    icon.setAttribute("aria-hidden", "true");

                    if (i === 0) {
                        button.setAttribute("aria-label", "add to cart");
                        icon.setAttribute("name", "bag-handle-outline");
                        button.addEventListener("click", function () {
                            console.log("Add to cart button clicked!" + item.id);
                            fetch("/api/add-to-cart", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                },
                                body: JSON.stringify({
                                    id: item.id,
                                    pname: item.pname,
                                    actualprice: item.actualprice,
                                    image: item.image,
                                }),
                            })
                                .then((response) => {
                                    if (!response.ok) {
                                        throw new Error("Failed to add item to cart");
                                    }
                                    return response.json();
                                })
                                .then((data) => {
                                    console.log(data.message);
                                    alert(data.message);
                                    setTimeout(() => {
                                        window.location.href = "cart.html";
                                    }, 1000); // Display success message or handle as needed
                                })
                                .catch((error) => {
                                    console.error("Error:", error);
                                });
                        });
                    } else {
                        button.setAttribute("aria-label", "add to whishlist");
                        icon.setAttribute("name", "star-outline");
                        button.addEventListener("click", function () {
                            console.log("Add to cart button clicked!" + item.id);
                            fetch("/api/add-to-wishlist", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                },
                                body: JSON.stringify({
                                    id: item.id,
                                    pname: item.pname,
                                    stars: item.stars,
                                    reviews: item.reviews,
                                    originalprice: item.originalprice,
                                    actualprice: item.actualprice,
                                    image: item.image,
                                    discount: item.discount,
                                }),
                            })
                                .then((response) => {
                                    if (!response.ok) {
                                        throw new Error("Failed to add item to wishlist");
                                    }
                                    return response.json();
                                })
                                .then((data) => {
                                    console.log(data.message);
                                    alert(data.message);
                                    setTimeout(() => {
                                        window.location.href = "favorite.html";
                                    }, 1000); // Display success message or handle as needed
                                })
                                .catch((error) => {
                                    console.error("Error:", error);
                                });
                        });
                    }

                    button.appendChild(icon);
                    divCardActions.appendChild(button);
                }

                // Append elements to the card-banner div
                divCardBanner.appendChild(imgElement);
                divCardBanner.appendChild(spanBadge);
                divCardBanner.appendChild(divCardActions);

                // Create div element with class "card-content"
                const divCardContent = document.createElement("div");
                divCardContent.classList.add("card-content");

                // Create del element with class "del" and span element with class "span"
                const delElement = document.createElement("del");
                delElement.classList.add("del");
                delElement.textContent = `$${item.originalprice}`;

                const spanPrice = document.createElement("span");
                spanPrice.classList.add("span");
                spanPrice.textContent = `$${item.actualprice}`;

                // Append elements to the price div
                const divPrice = document.createElement("div");
                divPrice.classList.add("price");
                divPrice.appendChild(delElement);
                divPrice.appendChild(spanPrice);

                // Create h3 element with a nested anchor element
                const h3Element = document.createElement("h3");
                const anchorElement = document.createElement("a");
                anchorElement.setAttribute("href", "#");
                anchorElement.classList.add("card-title");
                anchorElement.textContent = `${item.pname}`;
                h3Element.appendChild(anchorElement);

                // Create div element with class "card-rating"
                const divCardRating = document.createElement("div");
                divCardRating.classList.add("card-rating");

                // Create div element with class "rating-wrapper" and nested ion-icon elements
                const divRatingWrapper = document.createElement("div");
                divRatingWrapper.classList.add("rating-wrapper");
                divRatingWrapper.setAttribute("aria-label", "5 start rating");

                for (let i = 0; i < item.stars; i++) {
                    const icon = document.createElement("ion-icon");
                    icon.setAttribute("name", "star");
                    icon.setAttribute("aria-hidden", "true");
                    divRatingWrapper.appendChild(icon);
                }

                // Create p element with class "rating-text"
                const pRatingText = document.createElement("p");
                pRatingText.classList.add("rating-text");
                pRatingText.textContent = `${item.reviews} reviews`;

                // Append elements to the card-rating div
                divCardRating.appendChild(divRatingWrapper);
                divCardRating.appendChild(pRatingText);

                // Append elements to the card-content div
                divCardContent.appendChild(divPrice);
                divCardContent.appendChild(h3Element);
                divCardContent.appendChild(divCardRating);

                // Append elements to the shop-card div
                divShopCard.appendChild(divCardBanner);
                divShopCard.appendChild(divCardContent);

                // Append the shop-card div to the li element
                liElement.appendChild(divShopCard);

                // Append the created li element to a parent element in your actual HTML document
                // For example, assuming you have an unordered list with ID 'scrollbarList'
                // const parentElement = document.getElementById("scrollbarList");
                dataContainer.appendChild(liElement);
            });
        })
        .catch((error) => {
            console.error("There was a problem fetching the data:", error);
        });
}

window.onload = load;
